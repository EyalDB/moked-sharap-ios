import React, { useState, useEffect } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { Phone, Smartphone, Monitor, Settings, X, Check, Shield, Zap, Globe, Plus, Trash2, Edit2, User, Home, Briefcase, Heart, AlertCircle, Lock, LogOut, Eye, EyeOff } from 'lucide-react';

interface SpeedDialContact {
  id: string;
  label: string;
  number: string;
  icon: string;
}

const ICON_OPTIONS = [
  { value: 'user', label: 'Person', icon: User },
  { value: 'home', label: 'Home', icon: Home },
  { value: 'briefcase', label: 'Office', icon: Briefcase },
  { value: 'heart', label: 'Family', icon: Heart },
  { value: 'alert', label: 'Emergency', icon: AlertCircle },
  { value: 'phone', label: 'Phone', icon: Phone },
];

const getIconComponent = (iconValue: string) => {
  const found = ICON_OPTIONS.find(opt => opt.value === iconValue);
  return found ? found.icon : Phone;
};

const DEFAULT_ADMIN_PIN = '1234';
const APP_LOGO = 'https://d64gsuwffb70l.cloudfront.net/68e9f17482034e6aafbc0b5d_1766955608216_493240d1.jpeg';


// Fixed main contact - cannot be changed
const MAIN_CONTACT_NUMBER = '+972732341234';
const MAIN_CONTACT_LABEL = 'מוקד שרפ';


const AppLayout: React.FC = () => {
  const isMobile = useIsMobile();
  
  // Admin mode state
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [showPin, setShowPin] = useState(false);
  
  // Admin PIN (can be changed by admin)
  const [adminPin, setAdminPin] = useState(() => {
    return localStorage.getItem('adminPin') || DEFAULT_ADMIN_PIN;
  });
  
  // Primary number is now fixed - using constants
  const primaryNumber = MAIN_CONTACT_NUMBER;
  const primaryLabel = MAIN_CONTACT_LABEL;



  // Speed dial contacts
  const [speedDialContacts, setSpeedDialContacts] = useState<SpeedDialContact[]>(() => {
    const saved = localStorage.getItem('speedDialContacts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return [];
      }
    }
    return [];
  });

  // UI State
  const [showSettings, setShowSettings] = useState(false);
  const [editingContact, setEditingContact] = useState<SpeedDialContact | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [callInitiated, setCallInitiated] = useState(false);
  const [callingId, setCallingId] = useState<string | null>(null);
  const [platform, setPlatform] = useState<'android' | 'ios' | 'desktop'>('desktop');

  // Form state for editing speed dial contacts
  const [formLabel, setFormLabel] = useState('');
  const [formNumber, setFormNumber] = useState('');
  const [formIcon, setFormIcon] = useState('phone');
  
  // PIN change form state
  const [showChangePinForm, setShowChangePinForm] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');

  // Detect platform
  useEffect(() => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/android/i.test(userAgent)) {
      setPlatform('android');
    } else if (/iphone|ipad|ipod/i.test(userAgent)) {
      setPlatform('ios');
    } else {
      setPlatform('desktop');
    }
  }, []);

  // Save speed dial contacts to localStorage
  useEffect(() => {
    localStorage.setItem('speedDialContacts', JSON.stringify(speedDialContacts));
  }, [speedDialContacts]);

  // Helper function to format phone number for tel: link
  const formatPhoneForCall = (number: string) => {
    // Remove all non-numeric characters except +
    return number.replace(/[^0-9+]/g, '');
  };

  // Handle call - directly trigger phone call
  const handleCallClick = (phoneNumber: string, id: string) => {
    const formattedNumber = formatPhoneForCall(phoneNumber);
    setCallInitiated(true);
    setCallingId(id);
    
    // Use window.location for more reliable phone call initiation on iOS
    window.location.href = `tel:${formattedNumber}`;
    
    setTimeout(() => {
      setCallInitiated(false);
      setCallingId(null);
    }, 2000);
  };



  const openAddContact = () => {
    setFormLabel('');
    setFormNumber('');
    setFormIcon('phone');
    setIsAddingNew(true);
    setEditingContact(null);
  };

  const openEditContact = (contact: SpeedDialContact) => {
    setFormLabel(contact.label);
    setFormNumber(contact.number);
    setFormIcon(contact.icon);
    setEditingContact(contact);
    setIsAddingNew(false);
  };

  const saveContact = () => {
    if (!formLabel.trim() || !formNumber.trim()) return;

    if (isAddingNew) {
      const newContact: SpeedDialContact = {
        id: Date.now().toString(),
        label: formLabel.trim(),
        number: formNumber.trim(),
        icon: formIcon,
      };
      setSpeedDialContacts(prev => [...prev, newContact]);
    } else if (editingContact) {
      setSpeedDialContacts(prev =>
        prev.map(c =>
          c.id === editingContact.id
            ? { ...c, label: formLabel.trim(), number: formNumber.trim(), icon: formIcon }
            : c
        )
      );
    }

    setIsAddingNew(false);
    setEditingContact(null);
    setFormLabel('');
    setFormNumber('');
    setFormIcon('phone');
  };

  const deleteContact = (id: string) => {
    setSpeedDialContacts(prev => prev.filter(c => c.id !== id));
  };

  const cancelEdit = () => {
    setIsAddingNew(false);
    setEditingContact(null);
    setFormLabel('');
    setFormNumber('');
    setFormIcon('phone');
  };

  const formatPhoneDisplay = (number: string) => {
    return number || 'Not Set';
  };

  const getPlatformIcon = () => {
    switch (platform) {
      case 'android':
      case 'ios':
        return <Smartphone className="w-5 h-5" />;
      default:
        return <Monitor className="w-5 h-5" />;
    }
  };

  const getPlatformMessage = () => {
    switch (platform) {
      case 'android':
        return 'לחץ לפתיחת החייגן';
      case 'ios':
        return 'לחץ להתקשר מהאייפון';
      default:
        return 'לחץ להתקשרות';
    }
  };

  const canAddMore = speedDialContacts.length < 5;

  // Admin login handler
  const handleAdminLogin = () => {
    if (pinInput === adminPin) {
      setIsAdmin(true);
      setShowLoginModal(false);
      setPinInput('');
      setPinError(false);
    } else {
      setPinError(true);
      setTimeout(() => setPinError(false), 2000);
    }
  };

  const handleAdminLogout = () => {
    setIsAdmin(false);
    setShowSettings(false);
  };

  const handleChangePin = () => {
    if (newPin.length >= 4 && newPin === confirmPin) {
      setAdminPin(newPin);
      localStorage.setItem('adminPin', newPin);
      setShowChangePinForm(false);
      setNewPin('');
      setConfirmPin('');
    }
  };

  // CLIENT VIEW - Simple, clean interface with only the main call button
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-950 via-slate-900 to-slate-900 flex flex-col" dir="rtl">
        {/* Header */}
        <header className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-red-900/50">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src={APP_LOGO} 
                alt="מוקד שרפ" 
                className="w-12 h-12 rounded-xl object-contain"
              />
              <span className="text-2xl font-black text-white">מוקד שרפ</span>
            </div>
            <button
              onClick={() => setShowLoginModal(true)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors text-slate-400 hover:text-white"
              aria-label="כניסת מנהל"
            >
              <Lock className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Main Content - Centered Call Button */}
        <main className="flex-1 flex flex-col items-center justify-center px-4 pt-20">
          {/* Platform Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800/80 rounded-full border border-red-900/50 mb-8">
            {getPlatformIcon()}
            <span className="text-sm text-slate-300">{getPlatformMessage()}</span>
          </div>

          {/* Logo */}
          <div className="mb-6">
            <img 
              src={APP_LOGO} 
              alt="מוקד שרפ" 
              className="w-24 h-24 sm:w-32 sm:h-32 rounded-2xl object-contain shadow-2xl shadow-red-500/20"
            />
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 text-center leading-tight">
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400">
              מוקד שרפ
            </span>
            לחץ להתקשר
          </h1>

          {/* Current Number Display */}
          <div className="mb-8 text-center">
            <p className="text-sm text-slate-500 mb-1">{primaryLabel}</p>
            <p className="text-2xl sm:text-3xl font-mono font-bold text-white tracking-wider" dir="ltr">
              {formatPhoneDisplay(primaryNumber)}
            </p>
          </div>
          {/* Main Call Button - Using button for reliable phone calls */}
          <div className="relative inline-block mb-8">
            {/* Pulse Animation */}
            <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-20"></div>
            <div className="absolute inset-0 bg-red-500 rounded-full animate-pulse opacity-30 animation-delay-150"></div>
            
            <button
              onClick={() => handleCallClick(primaryNumber, 'primary')}
              className={`
                relative w-40 h-40 sm:w-48 sm:h-48 rounded-full 
                bg-gradient-to-br from-red-400 via-red-500 to-red-600
                hover:from-red-300 hover:via-red-400 hover:to-red-500
                active:scale-95 transition-all duration-200
                shadow-2xl shadow-red-500/30 hover:shadow-red-500/50
                flex items-center justify-center
                group
                cursor-pointer
                border-0
              `}
              aria-label="התקשר עכשיו"
            >
              <Phone className="w-16 h-16 sm:w-20 sm:h-20 text-white group-hover:scale-110 transition-transform" />
            </button>
          </div>



          {/* Call Status */}
          {callInitiated && callingId === 'primary' && (
            <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 bg-red-500/20 rounded-full border border-red-500/30">
              <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
              <span className="text-red-400 text-sm font-medium">מתחבר...</span>
            </div>
          )}


          {/* Trust Indicators */}
          <div className="flex items-center gap-6 mt-8 text-slate-500">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-red-500" />
              <span className="text-xs">מאובטח</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-red-500" />
              <span className="text-xs">מהיר</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-red-500" />
              <span className="text-xs">זמין תמיד</span>
            </div>
          </div>
        </main>

        {/* Speed Dial Contacts Section - Client View */}
        {speedDialContacts.length > 0 && (
          <section className="py-8 px-4 bg-slate-800/30">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-lg font-bold text-white text-center mb-6">אנשי קשר נוספים</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                {speedDialContacts.map((contact) => {
                  const IconComponent = getIconComponent(contact.icon);
                  const isCalling = callInitiated && callingId === contact.id;
                  return (
                    <button
                      key={contact.id}
                      onClick={() => handleCallClick(contact.number, contact.id)}
                      className={`
                        relative p-4 rounded-2xl bg-slate-800/50 border border-slate-700 
                        hover:border-red-500/50 hover:bg-slate-800
                        active:scale-95 transition-all duration-200
                        flex flex-col items-center gap-3
                        group
                        cursor-pointer
                      `}
                    >
                      <div className={`
                        w-14 h-14 rounded-full flex items-center justify-center
                        ${isCalling 
                          ? 'bg-red-500 animate-pulse' 
                          : 'bg-gradient-to-br from-slate-600 to-slate-700 group-hover:from-red-500 group-hover:to-red-600'
                        }
                        transition-all duration-200
                      `}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-center">
                        <p className="text-white font-medium text-sm truncate max-w-full">{contact.label}</p>
                        <p className="text-slate-500 text-xs truncate max-w-full" dir="ltr">{contact.number}</p>
                      </div>
                      {isCalling && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-400 rounded-full animate-ping"></div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </section>
        )}


        {/* Footer */}
        <footer className="py-6 px-4 border-t border-red-900/30">
          <div className="max-w-6xl mx-auto text-center">
            <p className="text-slate-600 text-xs mb-2">
              © 2025 מוקד שרפ. כל הזכויות שמורות.
            </p>
            <a 
              href="/privacy" 
              className="text-slate-500 hover:text-red-400 text-xs transition-colors"
            >
              מדיניות פרטיות
            </a>
          </div>
        </footer>

        {/* Admin Login Modal */}
        {showLoginModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="w-full max-w-sm bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl">
              <div className="flex items-center justify-between p-6 border-b border-slate-700">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Lock className="w-5 h-5 text-red-400" />
                  כניסת מנהל
                </h2>
                <button
                  onClick={() => {
                    setShowLoginModal(false);
                    setPinInput('');
                    setPinError(false);
                  }}
                  className="p-2 rounded-lg hover:bg-slate-700 transition-colors text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                <p className="text-slate-400 text-sm">הזן קוד PIN לגישה להגדרות.</p>
                
                <div className="relative">
                  <input
                    type={showPin ? 'text' : 'password'}
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAdminLogin()}
                    placeholder="הזן PIN"
                    className={`w-full px-4 py-3 bg-slate-900 border rounded-xl text-white text-center text-2xl tracking-widest placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                      pinError ? 'border-red-500 shake' : 'border-slate-600'
                    }`}
                    maxLength={8}
                    autoFocus
                    dir="ltr"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPin ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                
                {pinError && (
                  <p className="text-red-400 text-sm text-center">קוד שגוי. נסה שוב.</p>
                )}
                
                <button
                  onClick={handleAdminLogin}
                  className="w-full px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 rounded-xl text-white font-medium transition-colors"
                >
                  כניסה
                </button>
                
                <p className="text-slate-500 text-xs text-center" dir="ltr">Default PIN: 1234</p>
              </div>
            </div>
          </div>
        )}

        <style>{`
          @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
          }
          .shake {
            animation: shake 0.3s ease-in-out;
          }
        `}</style>
      </div>
    );
  }

  // ADMIN VIEW - Full dashboard with settings and speed dial management
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-950 via-slate-900 to-slate-900" dir="rtl">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-red-900/50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src={APP_LOGO} 
              alt="מוקד שרפ" 
              className="w-12 h-12 rounded-xl object-contain"
            />
            <div>
              <span className="text-2xl font-black text-white">מוקד שרפ</span>
              <span className="mr-2 px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs font-medium rounded-full">מנהל</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors text-slate-300 hover:text-white"
              aria-label="הגדרות"
            >
              <Settings className="w-5 h-5" />
            </button>

            <button
              onClick={handleAdminLogout}
              className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 transition-colors text-red-400 hover:text-red-300"
              aria-label="יציאה"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-24 pb-8 px-4 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-b from-red-900/20 via-transparent to-transparent"></div>

        <div className="relative max-w-4xl mx-auto text-center">
          {/* Admin Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/20 rounded-full border border-amber-500/30 mb-6">
            <Lock className="w-4 h-4 text-amber-400" />
            <span className="text-sm text-amber-400 font-medium">מצב מנהל</span>
          </div>

          {/* Platform Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800/80 rounded-full border border-slate-700 mb-8 mr-2">
            {getPlatformIcon()}
            <span className="text-sm text-slate-300">{getPlatformMessage()}</span>
          </div>

          {/* Logo */}
          <div className="mb-6 flex justify-center">
            <img 
              src={APP_LOGO} 
              alt="מוקד שרפ" 
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-contain shadow-2xl shadow-red-500/20"
            />
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-white mb-6 leading-tight">
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400">
              מוקד שרפ
            </span>
            התחברות מיידית
          </h1>

          <p className="text-lg sm:text-xl text-slate-400 mb-8 max-w-2xl mx-auto">
            התקשרות מהירה ואמינה מכל מכשיר. עובד על אנדרואיד, אייפון ודפדפנים.
          </p>

          {/* Current Number Display */}
          <div className="mb-6">
            <p className="text-sm text-slate-500 mb-1">{primaryLabel}</p>
            <p className="text-2xl sm:text-3xl font-mono font-bold text-white tracking-wider" dir="ltr">
              {formatPhoneDisplay(primaryNumber)}
            </p>
          </div>

          {/* Main Call Button - Using anchor tag */}
          <div className="relative inline-block mb-8">
            {/* Pulse Animation */}
            <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-20"></div>
            <div className="absolute inset-0 bg-red-500 rounded-full animate-pulse opacity-30 animation-delay-150"></div>
            
            <a
              href={`tel:${formatPhoneForCall(primaryNumber)}`}
              onClick={() => handleCallClick('primary')}
              className={`
                relative w-36 h-36 sm:w-44 sm:h-44 rounded-full 
                bg-gradient-to-br from-red-400 via-red-500 to-red-600
                hover:from-red-300 hover:via-red-400 hover:to-red-500
                active:scale-95 transition-all duration-200
                shadow-2xl shadow-red-500/30 hover:shadow-red-500/50
                flex items-center justify-center
                group
                cursor-pointer
              `}
              aria-label="התקשר עכשיו"
            >
              <Phone className="w-14 h-14 sm:w-16 sm:h-16 text-white group-hover:scale-110 transition-transform" />
            </a>
          </div>

          {/* Call Status */}
          {callInitiated && callingId === 'primary' && (
            <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 bg-red-500/20 rounded-full border border-red-500/30">
              <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
              <span className="text-red-400 text-sm font-medium">מתחבר...</span>
            </div>
          )}
        </div>
      </section>

      {/* Speed Dial Section */}
      <section className="py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">חיוג מהיר</h2>
            <span className="text-sm text-slate-500">{speedDialContacts.length}/5 אנשי קשר</span>
          </div>

          {speedDialContacts.length === 0 ? (
            <div className="text-center py-12 bg-slate-800/30 rounded-2xl border border-slate-700/50">
              <Phone className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400 mb-4">אין עדיין אנשי קשר לחיוג מהיר</p>
              <button
                onClick={() => {
                  openAddContact();
                  setShowSettings(true);
                }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                הוסף איש קשר ראשון
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {speedDialContacts.map((contact) => {
                const IconComponent = getIconComponent(contact.icon);
                const isCalling = callInitiated && callingId === contact.id;
                
                return (
                  <a
                    key={contact.id}
                    href={`tel:${formatPhoneForCall(contact.number)}`}
                    onClick={() => handleCallClick(contact.id)}
                    className={`
                      relative p-4 rounded-2xl bg-slate-800/50 border border-slate-700 
                      hover:border-red-500/50 hover:bg-slate-800
                      active:scale-95 transition-all duration-200
                      flex flex-col items-center gap-3
                      group
                      cursor-pointer
                      no-underline
                    `}
                  >
                    <div className={`
                      w-14 h-14 rounded-full flex items-center justify-center
                      ${isCalling 
                        ? 'bg-red-500 animate-pulse' 
                        : 'bg-gradient-to-br from-slate-600 to-slate-700 group-hover:from-red-500 group-hover:to-red-600'
                      }
                      transition-all duration-200
                    `}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-center">
                      <p className="text-white font-medium text-sm truncate max-w-full">{contact.label}</p>
                      <p className="text-slate-500 text-xs truncate max-w-full" dir="ltr">{contact.number}</p>
                    </div>
                    {isCalling && (
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-400 rounded-full animate-ping"></div>
                    )}
                  </a>
                );
              })}

              {/* Add More Button */}
              {canAddMore && (
                <button
                  onClick={() => {
                    openAddContact();
                    setShowSettings(true);
                  }}
                  className="p-4 rounded-2xl border-2 border-dashed border-slate-700 hover:border-red-500/50 flex flex-col items-center justify-center gap-2 transition-colors min-h-[140px]"
                >
                  <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center">
                    <Plus className="w-6 h-6 text-slate-500" />
                  </div>
                  <p className="text-slate-500 text-sm">הוסף איש קשר</p>
                </button>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-slate-800/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-bold text-white text-center mb-12">
            עובד בכל מקום
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Android */}
            <div className={`p-6 rounded-2xl bg-slate-800/50 border ${platform === 'android' ? 'border-red-500' : 'border-slate-700'} transition-all hover:border-red-500/50`}>
              <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center mb-4">
                <Smartphone className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">אנדרואיד</h3>
              <p className="text-slate-400">
                פותח את החייגן הטבעי מיידית. פשוט לחץ והתקשר.
              </p>
              {platform === 'android' && (
                <div className="mt-4 inline-flex items-center gap-2 text-red-400 text-sm">
                  <Check className="w-4 h-4" />
                  <span>המכשיר הנוכחי שלך</span>
                </div>
              )}
            </div>

            {/* iOS */}
            <div className={`p-6 rounded-2xl bg-slate-800/50 border ${platform === 'ios' ? 'border-red-500' : 'border-slate-700'} transition-all hover:border-red-500/50`}>
              <div className="w-14 h-14 bg-gradient-to-br from-slate-400 to-slate-600 rounded-xl flex items-center justify-center mb-4">
                <Smartphone className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">אייפון / אייפד</h3>
              <p className="text-slate-400">
                משתלב בצורה חלקה עם אפליקציית הטלפון של iOS להתקשרות מיידית.
              </p>
              {platform === 'ios' && (
                <div className="mt-4 inline-flex items-center gap-2 text-red-400 text-sm">
                  <Check className="w-4 h-4" />
                  <span>המכשיר הנוכחי שלך</span>
                </div>
              )}
            </div>

            {/* Desktop */}
            <div className={`p-6 rounded-2xl bg-slate-800/50 border ${platform === 'desktop' ? 'border-red-500' : 'border-slate-700'} transition-all hover:border-red-500/50`}>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center mb-4">
                <Monitor className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">דפדפן שולחני</h3>
              <p className="text-slate-400">
                עובד עם Skype, FaceTime או כל אפליקציית VoIP שמותקנת.
              </p>
              {platform === 'desktop' && (
                <div className="mt-4 inline-flex items-center gap-2 text-red-400 text-sm">
                  <Check className="w-4 h-4" />
                  <span>המכשיר הנוכחי שלך</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            <div className="p-6">
              <Shield className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-1">מאובטח</h3>
              <p className="text-slate-400 text-sm">נתונים נשמרים מקומית במכשיר שלך</p>
            </div>
            <div className="p-6">
              <Zap className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-1">מיידי</h3>
              <p className="text-slate-400 text-sm">לחיצה אחת להתחברות</p>
            </div>
            <div className="p-6">
              <Globe className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-1">אוניברסלי</h3>
              <p className="text-slate-400 text-sm">עובד על כל מכשיר</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-red-900/30">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <img 
              src={APP_LOGO} 
              alt="מוקד שרפ" 
              className="w-10 h-10 rounded-lg object-contain"
            />
            <span className="text-lg font-black text-white">מוקד שרפ</span>
          </div>
          <p className="text-slate-500 text-sm">
            התקשרות פשוטה, מהירה ואמינה מכל מכשיר.
          </p>
          <p className="text-slate-600 text-xs mt-4 mb-2">
            © 2025 מוקד שרפ. כל הזכויות שמורות.
          </p>
          <a 
            href="/privacy" 
            className="text-slate-500 hover:text-red-400 text-xs transition-colors"
          >
            מדיניות פרטיות
          </a>
        </div>
      </footer>


      {/* Floating Action Button - Using anchor tag */}
      <a
        href={`tel:${formatPhoneForCall(primaryNumber)}`}
        onClick={() => handleCallClick('primary')}
        className="fixed bottom-6 left-6 w-16 h-16 bg-gradient-to-br from-red-400 to-red-600 rounded-full shadow-lg shadow-red-500/30 flex items-center justify-center hover:scale-110 active:scale-95 transition-transform z-40"
        aria-label="התקשר מהר"
      >
        <Phone className="w-7 h-7 text-white" />
      </a>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-lg bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl my-8">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <h2 className="text-xl font-bold text-white">הגדרות מנהל</h2>
              <button
                onClick={() => {
                  setShowSettings(false);
                  cancelEdit();
                  setShowChangePinForm(false);
                }}
                className="p-2 rounded-lg hover:bg-slate-700 transition-colors text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Main Contact Info (Read-only) */}
              <div>
                <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4">איש קשר ראשי (קבוע)</h3>
                <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center flex-shrink-0">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-bold text-lg">{primaryLabel}</p>
                      <p className="text-slate-400 font-mono" dir="ltr">{primaryNumber}</p>
                    </div>
                  </div>
                  <p className="text-slate-500 text-xs mt-3">מספר זה קבוע ולא ניתן לשינוי</p>
                </div>
              </div>


              {/* Speed Dial Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">חיוג מהיר ({speedDialContacts.length}/5)</h3>
                  {canAddMore && !isAddingNew && !editingContact && (
                    <button
                      onClick={openAddContact}
                      className="text-sm text-red-400 hover:text-red-300 flex items-center gap-1"
                    >
                      <Plus className="w-4 h-4" />
                      הוסף
                    </button>
                  )}
                </div>

                {/* Add/Edit Form */}
                {(isAddingNew || editingContact) && (
                  <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-600 mb-4 space-y-4">
                    <h4 className="text-white font-medium">
                      {isAddingNew ? 'הוסף איש קשר חדש' : 'ערוך איש קשר'}
                    </h4>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-2">תווית</label>
                      <input
                        type="text"
                        value={formLabel}
                        onChange={(e) => setFormLabel(e.target.value)}
                        placeholder="לדוגמה: בית, משרד, חירום"
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-2">מספר טלפון</label>
                      <input
                        type="tel"
                        value={formNumber}
                        onChange={(e) => setFormNumber(e.target.value)}
                        placeholder="הזן מספר טלפון"
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent font-mono"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-2">אייקון</label>
                      <div className="grid grid-cols-6 gap-2">
                        {ICON_OPTIONS.map((option) => {
                          const IconComp = option.icon;
                          return (
                            <button
                              key={option.value}
                              type="button"
                              onClick={() => setFormIcon(option.value)}
                              className={`p-3 rounded-lg flex items-center justify-center transition-colors ${
                                formIcon === option.value
                                  ? 'bg-red-500 text-white'
                                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                              }`}
                              title={option.label}
                            >
                              <IconComp className="w-5 h-5" />
                            </button>
                          );
                        })}
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={cancelEdit}
                        className="flex-1 px-4 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl text-white font-medium transition-colors"
                      >
                        ביטול
                      </button>
                      <button
                        onClick={saveContact}
                        disabled={!formLabel.trim() || !formNumber.trim()}
                        className="flex-1 px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 rounded-xl text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                      >
                        <Check className="w-5 h-5" />
                        {isAddingNew ? 'הוסף' : 'שמור'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Contacts List */}
                {speedDialContacts.length === 0 && !isAddingNew ? (
                  <div className="text-center py-8 text-slate-500">
                    <p>אין עדיין אנשי קשר לחיוג מהיר</p>
                    {canAddMore && (
                      <button
                        onClick={openAddContact}
                        className="mt-2 text-red-400 hover:text-red-300 text-sm"
                      >
                        הוסף איש קשר ראשון
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {speedDialContacts.map((contact) => {
                      const IconComponent = getIconComponent(contact.icon);
                      return (
                        <div
                          key={contact.id}
                          className="flex items-center gap-3 p-3 bg-slate-900/50 rounded-xl border border-slate-700"
                        >
                          <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                            <IconComponent className="w-5 h-5 text-slate-300" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-white font-medium truncate">{contact.label}</p>
                            <p className="text-slate-500 text-sm truncate" dir="ltr">{contact.number}</p>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => openEditContact(contact)}
                              className="p-2 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                              title="ערוך"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteContact(contact.id)}
                              className="p-2 rounded-lg hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition-colors"
                              title="מחק"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Change PIN Section */}
              <div>
                <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4">אבטחה</h3>
                
                {!showChangePinForm ? (
                  <button
                    onClick={() => setShowChangePinForm(true)}
                    className="w-full px-4 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl text-white font-medium transition-colors flex items-center justify-center gap-2"
                  >
                    <Lock className="w-5 h-5" />
                    שנה קוד PIN מנהל
                  </button>
                ) : (
                  <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-600 space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-2">PIN חדש (מינימום 4 תווים)</label>
                      <input
                        type="password"
                        value={newPin}
                        onChange={(e) => setNewPin(e.target.value)}
                        placeholder="הזן PIN חדש"
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-xl text-white text-center tracking-widest placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        maxLength={8}
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-2">אשר PIN</label>
                      <input
                        type="password"
                        value={confirmPin}
                        onChange={(e) => setConfirmPin(e.target.value)}
                        placeholder="אשר PIN חדש"
                        className="w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-xl text-white text-center tracking-widest placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        maxLength={8}
                        dir="ltr"
                      />
                    </div>
                    {newPin && confirmPin && newPin !== confirmPin && (
                      <p className="text-red-400 text-sm">הקודים לא תואמים</p>
                    )}
                    <div className="flex gap-3">
                      <button
                        onClick={() => {
                          setShowChangePinForm(false);
                          setNewPin('');
                          setConfirmPin('');
                        }}
                        className="flex-1 px-4 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl text-white font-medium transition-colors"
                      >
                        ביטול
                      </button>
                      <button
                        onClick={handleChangePin}
                        disabled={newPin.length < 4 || newPin !== confirmPin}
                        className="flex-1 px-4 py-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 rounded-xl text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        עדכן PIN
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-6 pt-0">
              <button
                onClick={() => {
                  setShowSettings(false);
                  cancelEdit();
                  setShowChangePinForm(false);
                }}
                className="w-full px-4 py-3 bg-slate-700 hover:bg-slate-600 rounded-xl text-white font-medium transition-colors"
              >
                סגור הגדרות
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppLayout;
